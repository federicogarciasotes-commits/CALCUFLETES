from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session, joinedload

from app.database import SessionLocal
from app.models.transportista import Transportista
from app.models.transportista_destino import TransportistaDestino
from app.models.transportista_dia import TransportistaDia

from app.schemas.transportista import (
    TransportistaCreate,
    TransportistaResponse,
    TransportistaListado
)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def transportista_to_dict(t: Transportista):
    return {
        "id": t.id,
        "nombre": t.nombre,
        "descripcion": t.descripcion,
        "destinos": [d.localidad.nombre for d in t.destinos_ids],
        "dias": [d.dia_reparto.nombre for d in t.dias_ids]
    }


router = APIRouter(
    prefix="/transportistas",
    tags=["Transportistas"]
)


@router.post("/", response_model=TransportistaResponse)
def crear_transportista(data: TransportistaCreate, db: Session = Depends(get_db)):

    transportista = Transportista(
        nombre=data.nombre,
        descripcion=data.descripcion
    )

    db.add(transportista)
    db.commit()
    db.refresh(transportista)

    # destinos
    for destino_id in data.destinos_ids:
        destino = TransportistaDestino(
            transportista_id=transportista.id,
            localidad_id=destino_id
        )
        db.add(destino)

    # dias
    for dia_id in data.dias_ids:
        relacion = TransportistaDia(
            transportista_id=transportista.id,
            dia_id=dia_id
        )
        db.add(relacion)

    db.commit()

    return {
        "id": transportista.id,
        "nombre": transportista.nombre,
        "descripcion": transportista.descripcion,
        "destinos_ids": data.destinos_ids,
        "dias_ids": data.dias_ids
    }


@router.get("/por-destino/{localidad_id}")
def transportistas_por_destino(localidad_id: int, db: Session = Depends(get_db)):

    transportistas = (
        db.query(Transportista)
        .join(TransportistaDestino)
        .filter(TransportistaDestino.localidad_id == localidad_id)
        .all()
    )

    return [
        {
            "id": t.id,
            "nombre": t.nombre,
            "descripcion": t.descripcion
        }
        for t in transportistas
    ]


@router.get("/listar", response_model=list[TransportistaResponse])
def listar_transportistas(db: Session = Depends(get_db)):

    transportistas = (
        db.query(Transportista)
        .options(
            joinedload(Transportista.destinos_ids),
            joinedload(Transportista.dias_ids)
        )
        .all()
    )

    resultado = []

    for t in transportistas:

        dest_ids = [d.localidad_id for d in t.destinos_ids]
        dias_ids = [d.dia_id for d in t.dias_ids]

        resultado.append({
            "id": t.id,
            "nombre": t.nombre,
            "descripcion": t.descripcion,
            "destinos_ids": dest_ids,
            "dias_ids": dias_ids
        })

    return resultado


@router.get("/listar/nombres", response_model=list[TransportistaListado])
def listar_transportistas_completo(db: Session = Depends(get_db)):

    transportistas = (
        db.query(Transportista)
        .options(
            joinedload(Transportista.destinos_ids).joinedload(TransportistaDestino.localidad),
            joinedload(Transportista.dias_ids).joinedload(TransportistaDia.dia_reparto)
        )
        .all()
    )

    return [transportista_to_dict(t) for t in transportistas]


@router.get("/{transportista_id}", response_model=TransportistaListado)
def obtener_transportista(transportista_id: int, db: Session = Depends(get_db)):

    transportista = (
        db.query(Transportista)
        .options(
            joinedload(Transportista.destinos_ids).joinedload(TransportistaDestino.localidad),
            joinedload(Transportista.dias_ids).joinedload(TransportistaDia.dia_reparto)
        )
        .filter(Transportista.id == transportista_id)
        .first()
    )

    if not transportista:
        raise HTTPException(
            status_code=404,
            detail="Transportista no encontrado"
        )

    return transportista_to_dict(transportista)