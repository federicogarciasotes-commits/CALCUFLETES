import asyncio
from .proveedores.factory import obtener_proveedor
from app.repositories.transportista_repository import TransportistaRepository
from app.schemas.cotizacion import Bulto


class CotizadorService:

    def __init__(self, db):
        self.repo = TransportistaRepository(db)
        
    
    def generar_bultos(self, cantidad_bultos, peso_total):

        ALTO = 0.5
        ANCHO = 1
        LARGO = 2
        VOLUMEN = ALTO * ANCHO * LARGO

        peso_por_bulto = peso_total / cantidad_bultos

        bultos = []

        for _ in range(cantidad_bultos):

            bultos.append(
                Bulto(
                    peso=peso_por_bulto,
                    alto=ALTO,
                    ancho=ANCHO,
                    largo=LARGO,
                    volumen=VOLUMEN
                )
            )

        return bultos
        

    async def cotizar_envio(self, data):

        # origen
        localidad_origen = self.repo.obtener_localidad(data.localidad_origen_id)
        cp_origen = localidad_origen.cp_principal

        # destino
        localidad_destino = self.repo.obtener_localidad(data.localidad_destino_id)
        cp_destino = localidad_destino.cp_principal

        # 2 transportistas que llegan
        transportistas = self.repo.obtener_por_localidad(
            data.localidad_destino_id
        )
        
        bultos = self.generar_bultos(
            data.cantidad_bultos,
            data.peso_total
        )

        tareas = []

        for t in transportistas:

            proveedor = obtener_proveedor(t.nombre)

            if not proveedor:
                continue

            tareas.append(
                proveedor.cotizar(
                    cp_origen,
                    cp_destino,
                    bultos
                )
            )

        resultados = await asyncio.gather(*tareas)

        resultados.sort(key=lambda x: x["precio"])

        return resultados